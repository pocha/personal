package stalkninja.sqlitehelper;




import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;
import android.content.Context;
import android.util.Log;
import android.database.Cursor;


public class SqliteDB extends SQLiteOpenHelper {
	
	private SQLiteDatabase db;  //Use this variable to do all your database insert & select function.
	
	private static final int DATABASE_VERSION = 2;
	private static final String DATABASE_NAME = "sample_db";
	private static final String SAMPLE_TABLE_NAME = "sample_table";
	private static final String DATABASE_CREATE ="create table "+SAMPLE_TABLE_NAME +"(name primary key,"+
	"email text not null)";
	private static final String NAME = "name";
	private static final String EMAIL = "email";
	public SqliteDB(Context ctx) throws SQLiteException {
		super(ctx, DATABASE_NAME, null, DATABASE_VERSION); 
		db = this.getWritableDatabase();  //nitialises the databases.
		//initialize private variable 'db' here. Read about SQLiteOpenHelper class to know how to get the database handle. 
		//hint - we extended sqliteDB from SQLiteOpenHelper - so you can call functions of SQLiteOpenHelper with 'this'. For all the non-OOPS guy ;)
		
	}
	
	@Override	
	public void onOpen(SQLiteDatabase _db) { //This function is called whenever the database is OPENED by getWritableDatabase()/getReadableDatabase()
		System.out.println("inside onOpen");
		if(_db.findEditTable(SAMPLE_TABLE_NAME)==null) // not sure about this, but tried doing it.
			_db.execSQL(DATABASE_CREATE);
			
		
		
		
	}
	
	@Override	
	public void onCreate(SQLiteDatabase _db) { //This function is called when the database is CREATED by getWritableDatabase()/getReadableDatabase(). If the database is already created which would when you run the code first time, this function would NEVER be called again

		System.out.println("inside onCreate");
		_db.execSQL(DATABASE_CREATE);  // executes the raw sql statement
		
	}
	
	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		//leave it empty for now
	}

	public void insert(String name, String email){
		ContentValues initialValues = new ContentValues(); //contentvalues contains the data that has to be inserted into the database
		initialValues.put(NAME,name);
		initialValues.put(EMAIL,email);
		db.insertWithOnConflict(SAMPLE_TABLE_NAME, null, initialValues,db.CONFLICT_REPLACE); //In times of conflict, it replaces the old values
		
		//System.out.println("reached into insert");
	}

	public String select(String condition){
		String result = "nothing";
		Cursor mCursor = db.query(true, SAMPLE_TABLE_NAME, new String[]{"name","email"},condition,null, null,null, null,null);
		String name="";
		String email="";
		//System.out.println("reached here");
		if(mCursor!=null)
		{
			System.out.println("reached to select");
			int a = mCursor.getColumnCount();
			mCursor.moveToFirst();
			
			System.out.println(new Integer(a).toString());
			name= mCursor.getString(mCursor.getColumnIndex(NAME));
			email=mCursor.getString(mCursor.getColumnIndex(EMAIL));
		}
		
		
		//write code to select data from database & populate results array. The format should be - "name <yourname>: email <youremail>"
		//hint - you would need Cursor class & rawQuery function
		
		//sample return  - remove this while coding
		result= "name: "+name+" email: "+email;

		return result;
	}
	
	public void close() {
		db.close();
	}


}