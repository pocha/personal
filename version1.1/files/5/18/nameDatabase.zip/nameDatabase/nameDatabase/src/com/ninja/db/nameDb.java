package com.ninja.db;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

public class nameDb extends Activity implements OnClickListener{
	TextView text, name, myName, MobileText, MobileNumber;
	Button button, delButton;
	TableRow tableRow;
	boolean dbExists = false;
	
	nameDBAapter db = new nameDBAapter(this);
	

	/** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.addbutton);
        text = (TextView)findViewById(R.id.Text);
        dbExists = readDataFromDb();
       
        if(dbExists)
        {
        	db.open();
        	Cursor c = db.getTitle(1);
  	        if (c.moveToFirst())   
  	        {
  	            DisplayToast(c);
  	            dbExists = true;
  	        }
  	        db.close();
        	
        	text.setVisibility(View.INVISIBLE);
        	tableRow = (TableRow)findViewById(R.id.TableRow);
        	tableRow.setVisibility(View.VISIBLE);
        	myName = (TextView)findViewById(R.id.myName);
        	//readDataFromDb();
        	myName = (TextView)findViewById(R.id.myName);
        	Toast.makeText(this, 
                    "db exists" ,
                    Toast.LENGTH_LONG).show();
        }
        else
        {
        	
        	text.setVisibility(View.VISIBLE);
        	
        }
        	
        button = (Button)findViewById(R.id.AddButton);
        button.setOnClickListener(this);
 
        delButton = (Button)findViewById(R.id.DeleteButton);
        delButton.setOnClickListener(new OnClickListener(){
        	@Override
        	 public void onClick(View v) {
        		 db.deleteTitle(1);}});
       

}	
    @Override
	public void onClick(View v) {
    	openDatabase();
		
		readDataFromDb();
		
		Intent i = new Intent(nameDb.this, FirstScreen.class);
		startActivity(i);
	}
    
    public void openDatabase(){
    
    }
    
   public boolean readDataFromDb(){
    	db.open();
    	  Cursor c = db.getTitle(1);
	        if (c.moveToFirst())   
	        {
	            DisplayToast(c);
	            dbExists = true;
	        }
	        db.close();
	        return dbExists;
	     
    }
   
   public void DisplayToast(Cursor c)
   {
	   myName = (TextView)findViewById(R.id.myName);
   	Log.d("Display","display " + c.getString(0));
  // 	name = (TextView)findViewById(R.id.textName);
  //  setContentView(R.layout.table);
   	String name1 = c.getString(1); 
   	myName.setText(name1);
        
      /* Toast.makeText(this, 
               "id: " + c.getString(0) + "\n" +
               "NAME: " + c.getString(1) + "\n" +
               "MOBILE NUMBER: " + c.getString(2) + "\n",
               Toast.LENGTH_LONG).show();      */  
   	
   } 
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

 