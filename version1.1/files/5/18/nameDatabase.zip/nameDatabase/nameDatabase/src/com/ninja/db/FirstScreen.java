package com.ninja.db;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class FirstScreen extends Activity implements OnClickListener 
{
	Button saveButton;
	nameDBAapter db;
	EditText name, mobileNumber;
	static boolean dBCreated;
	String strName = null;
	
	 @Override
	public void onClick(View v) 
	{
		 if(!dBCreated)
			 saveDataInDB();
		 else
			 ModifyDb(name.getText().toString(), mobileNumber.getText().toString());
		 
		 Intent i = new Intent(FirstScreen.this, ListScreen.class);
		 readDb();
		 i.putExtra("STRING_I_NEED", strName);
		 startActivity(i);
	}
	  //** Called when the activity is first created. *//*
    @Override
    public void onCreate(Bundle savedInstanceState) 
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        name = (EditText)findViewById(R.id.NameEditText);
        mobileNumber = (EditText)findViewById(R.id.MobileNumberEditText);
        saveButton = (Button)findViewById(R.id.SaveButton);
        saveButton.setOnClickListener(this);
        db = new nameDBAapter(this);
    }
    
    private void ModifyDb(String userName, String userNumber)
    {
    	db.open();
    	db.updateTitle(1, userName, userNumber);
    	readDb();
    	db.close();    	
    }
    private void saveDataInDB()
    {
    	try
    	{
    		// ask the database manager to add a row given the two strings
    		 db.open();      
    	       
    	        db.insertInDb
    	        (
    	        		name.getText().toString(),
    	        		mobileNumber.getText().toString()  	        		
    			);	
    	        
    	       	        
    	        Cursor c = db.getTitle(1);
    	        if (c.moveToFirst())        
    	            DisplayToast(c);
    	       else
    	       {
    	            Toast.makeText(this, "No title found", 
    	            		Toast.LENGTH_LONG).show();
    	       }
    	        dBCreated = true;
    	        db.close();
    	}
    	catch (Exception e)
    	{
    		Log.e("Save Error", e.toString());
    		e.printStackTrace();
    	}
    }
    
    public void DisplayToast(Cursor c)
    {
    	Log.d("Display","display " + c.getString(0));
        Toast.makeText(this, 
                "id: " + c.getString(0) + "\n" +
                "NAME: " + c.getString(1) + "\n" +
                "MOBILE NUMBER: " + c.getString(2) + "\n",
                Toast.LENGTH_LONG).show(); 
        strName = c.getString(1);
    } 
    public void readDb()
    {
    	db.open();
    	 Cursor c = db.getTitle(1);
	        if (c.moveToFirst())        
	            DisplayToast(c);
	       else
	       {
	            Toast.makeText(this, "No title found", 
	            		Toast.LENGTH_LONG).show();
	       }
	    db.close();
    }
    
    
   
}
	
	
