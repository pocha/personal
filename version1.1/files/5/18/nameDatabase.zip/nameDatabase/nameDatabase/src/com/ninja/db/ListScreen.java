package com.ninja.db;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;


public class ListScreen extends Activity// implements OnClickListener 
{
	Bundle extras;

	 public void onCreate(Bundle savedInstanceState) 
	    {
	        super.onCreate(savedInstanceState);
	        setContentView(R.layout.table);
	        TextView userName = (TextView)findViewById(R.id.userName);
	       
	        String newString;
	        if (savedInstanceState == null) {
	            extras = getIntent().getExtras();
	            if(extras == null) {
	                newString= null;
	            } else {
	                newString= extras.getString("STRING_I_NEED");
	            }
	        } else {
	            newString= (String) savedInstanceState.getSerializable("STRING_I_NEED");
	        }
	        userName.setText(newString);
	        Toast.makeText(this, newString, 
            		Toast.LENGTH_LONG).show();
	    }
	 
	
}